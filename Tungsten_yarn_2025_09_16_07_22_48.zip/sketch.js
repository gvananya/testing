function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220,34,78);
  rectMode(CENTER);
  rect(200 ,200,70,80);
  rect(200,140,30,40);
  circle(150,150,40);
  circle(250,150,40);
  triangle(200,40,250,90,150,120);
  
}
